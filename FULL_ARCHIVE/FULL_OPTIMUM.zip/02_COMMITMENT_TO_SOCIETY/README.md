# 02 Commitment To Society

**Project:** OPTIMUM
**Upstream:** https://github.com/huggingface/optimum

Content specific to OPTIMUM in category CHIP_QUANTIZATION.
